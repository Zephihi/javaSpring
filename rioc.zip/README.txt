#####################BDD###############################


user= root
password = my-secret-pw


#######################MAVEN##############################"

Faire un clean install avec Maven


##########################SWAGGER################

Pour accéder au swagger:

http://localhost:8080/swagger-ui/