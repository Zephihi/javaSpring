package com.rioc.ws.controllers;

import com.rioc.ws.models.dao.dto.AdresseDto;
import com.rioc.ws.services.hello.adresse.IAdresseService;
import io.netty.handler.codec.json.JsonObjectDecoder;
import org.apache.tomcat.util.json.JSONParser;
import org.junit.jupiter.api.Assertions;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import springfox.documentation.spring.web.json.Json;

import java.util.List;

@RestController
public class AdresseController {
    private IAdresseService service;

    public AdresseController(IAdresseService service) {
        super();
        this.service = service;
    }
    @GetMapping("/adresse")
    public AdresseDto getAdresse(@RequestParam int id) {
        requestAdresseFromAPI();
        return service.getAdresseById(id);
    }
    @GetMapping("/adresse/all")
    public List<AdresseDto> getAllAdresse(){
        return service.getAllAdresse();
    }
    public void requestAdresseFromAPI(){
        RestTemplate restTemplate = new RestTemplate();
        String fooResourceUrl
                = "https://api-adresse.data.gouv.fr/search/?q=8+bd+du+port";
        ResponseEntity<String> response
                = restTemplate.getForEntity(fooResourceUrl + "/1", String.class);
        Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
        System.out.println(response);
    }
}
