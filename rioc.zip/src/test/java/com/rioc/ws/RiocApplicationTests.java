package com.rioc.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiocApplicationTests {

	@Test
	void contextLoads() {
	}

}
