package com.rioc.ws.services.hello.adresse;

import com.rioc.ws.models.dao.dto.AdresseDto;

import java.util.List;


public interface IAdresseService {
    public AdresseDto getAdresseById(int id);
    public List<AdresseDto> getAllAdresse();
}
