package com.rioc.ws.services.hello.adresse;

import com.rioc.ws.exceptions.ApiException;
import com.rioc.ws.repositories.mappers.IAdresseMapper;
import com.rioc.ws.models.dao.Adresse;
import com.rioc.ws.models.dao.dto.AdresseDto;
import com.rioc.ws.repositories.IAdresseRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AdresseService implements IAdresseService {
    private final IAdresseRepository adresseRepository;
    private final IAdresseMapper adresseMapper;

    public AdresseService(IAdresseRepository adresseRepository, IAdresseMapper adresseMapper) {
        super();
        this.adresseRepository = adresseRepository;
        this.adresseMapper = adresseMapper;
    }

    public AdresseDto getAdresseById(int id) {
        Optional<Adresse> optionAdresse=adresseRepository.findById(id);
        if(optionAdresse.isEmpty()){
            throw new ApiException("l'id n'existe pas", HttpStatus.NOT_FOUND);
        }
        return adresseMapper.AdresseToAdressDto(optionAdresse.get());
    }
    
    public List<AdresseDto> getAllAdresse() {
        List<Adresse> allAdresse = adresseRepository.findAll();
        if(allAdresse.isEmpty()){
            return null;
        }
        return allAdresse.stream().map(adresseMapper::AdresseToAdressDto).collect(Collectors.toList());
    }
}
