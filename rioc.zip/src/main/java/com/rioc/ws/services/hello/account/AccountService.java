package com.rioc.ws.services.hello.account;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rioc.ws.exceptions.ApiException;
import com.rioc.ws.repositories.mappers.IAccountMapper;
import com.rioc.ws.models.dao.dto.AccountDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.rioc.ws.models.dao.Account;
import com.rioc.ws.repositories.IAccountRepository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AccountService implements IAccountService {

	private final IAccountRepository repository;
	private final IAccountMapper mapper;

	public AccountService(IAccountRepository repository, IAccountMapper mapper) {
		super();
		this.repository = repository;
		this.mapper = mapper;
	}
	public boolean validateAddress(AccountDto account) throws JsonProcessingException {
		RestTemplate restTemplate = new RestTemplate();
		String streetNameParse = account.getAdresse().getStreetName().replace(" ", "+");
		try {
			String fooResourceUrl;
			if (account.getAdresse().getPostal() != 0) {
				fooResourceUrl
						= "https://api-adresse.data.gouv.fr/search/?q=" + account.getAdresse().getNumber() + "+" + streetNameParse + "&postcode=" + account.getAdresse().getPostal();
				System.out.println(fooResourceUrl);
			} else {
				fooResourceUrl
						= "https://api-adresse.data.gouv.fr/search/?q=" + account.getAdresse().getNumber() + "+" + streetNameParse;
			}
			ResponseEntity<String> response
					= restTemplate.getForEntity(fooResourceUrl, String.class);
			System.out.println(response.getBody());

			ObjectMapper map = new ObjectMapper();
			JsonNode root = map.readTree(response.getBody());
			double score = root.get("features").get(0).get("properties").get("score").asDouble();
			System.out.println(score);
			if (score > 0.4) return true;
			else return false;
	}
		catch (HttpClientErrorException e) {
			throw new ApiException("le postcode n'est pas valide",HttpStatus.BAD_REQUEST);
		}
		catch(NullPointerException a){
			throw new ApiException("le retour est vide, le postcode ne semble pas être valide",HttpStatus.BAD_REQUEST);
		}
	}

	public Account postAccount(AccountDto account) throws JsonProcessingException {
		if (!repository.findByFirstNameAndLastName(account.getFirstName(),account.getLastName()).isEmpty()){
			throw new ApiException("le compte existe déjà",HttpStatus.BAD_REQUEST);
		}
		System.out.println(validateAddress(account));
		if(validateAddress(account)){
			return repository.save(mapper.AccountDtoToAccount(account));
		}
		else {
			throw new ApiException("l'adresse n'est pas valide",HttpStatus.BAD_REQUEST);
		}

	}

	public AccountDto getAccountById(int id){
		Optional<Account> optionAccount = repository.findById(id);
		if(optionAccount.isEmpty()){
			throw new ApiException("l'id n'existe pas", HttpStatus.NOT_FOUND);
		}
		return mapper.AccountToAccountDto(optionAccount.get());
	}
	public List<AccountDto> getAllAccounts(){
		List<Account> allAccounts = repository.findAll();
		if(allAccounts.isEmpty()){
			return null;
		}
		return allAccounts.stream().map(mapper::AccountToAccountDto).collect(Collectors.toList());
	}

	public void deleteAccount(int id){
		repository.deleteById(id);
	}
}
