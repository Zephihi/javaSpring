package com.rioc.ws.services.hello.account;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rioc.ws.models.dao.Account;
import com.rioc.ws.models.dao.dto.AccountDto;

import java.util.List;

public interface IAccountService {
	public Account postAccount(AccountDto account) throws JsonProcessingException;
	public AccountDto getAccountById(int id);
	public List<AccountDto> getAllAccounts();
	public void deleteAccount(int id);
	public boolean validateAddress(AccountDto account) throws JsonProcessingException;
}
