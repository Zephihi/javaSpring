package com.rioc.ws.services.hello;

public interface IHelloService {
	public String getHelloForName(String name);

}
