package com.rioc.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiocApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiocApplication.class, args);
	}

}
