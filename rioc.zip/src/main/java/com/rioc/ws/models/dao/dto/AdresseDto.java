package com.rioc.ws.models.dao.dto;

import com.rioc.ws.models.dao.Account;
import com.sun.istack.NotNull;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

public class AdresseDto {
    @NotNull
    private int number;
    @NotNull @NotBlank @NotEmpty
    private String streetName;
    @NotNull @NotBlank @NotEmpty
    private String cityName;
    private int postal;

    public AdresseDto() {
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public int getPostal() {
        return postal;
    }

    public void setPostal(int postal) {
        this.postal = postal;
    }
}
