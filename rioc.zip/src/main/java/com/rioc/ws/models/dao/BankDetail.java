package com.rioc.ws.models.dao;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sun.istack.NotNull;
import javax.persistence.*;

@Entity

@Table(name = "BANK")
@JsonIgnoreProperties({"hibernateLazyInitialize","handler"})
public class BankDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "IBAN") @NotNull
    private String IBAN;

    @ManyToOne
    @JoinColumn(name="account", nullable=false)
    private Account account;

    public BankDetail() {
    }

    public String getIBAN() {
        return IBAN;
    }


    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
