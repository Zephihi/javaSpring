package com.rioc.ws.models.dao;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.io.Serializable;

@Entity

@Table(name = "ADRESSE")
@JsonIgnoreProperties({"hibernateLazyInitialize","handler"})
public class Adresse implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ADRESSE_ID",unique = true, nullable = false)
    private int adresseId;

    @OneToOne(mappedBy = "adresse")
    private Account accountLink;

    @Column(name = "NUMBER")
    private int number;

    @Column(name = "STREET")
    private String streetName;

    @Column(name = "CITY")
    private String cityName;

    @Column(name="POSTAL")
    private int postal;

        public Adresse() {
        // TODO Auto-Generated constructor stub
    }


    public Account getAccountLink() {
        return accountLink;
    }

    public void setAccountLink(Account accountLink) {
        this.accountLink = accountLink;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public int getAdresseId() {
        return adresseId;
    }

    public void setAdresseId(int adresseId) {
        this.adresseId = adresseId;
    }

    public int getPostal() {
        return postal;
    }

    public void setPostal(int postal) {
        this.postal = postal;
    }
}
