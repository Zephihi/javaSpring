package com.rioc.ws.models.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "ACCOUNT")
@JsonIgnoreProperties({"hibernateLazyInitialize","handler"})
public class Account implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ACCOUNT_ID",unique = true, nullable = false)
	private int accountId;
	
	@Column(name = "FIRST_NAME")
	private String firstName;
	
	@Column(name = "LAST_NAME")
	private String lastName;

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "adresse")
	private Adresse adresse;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "account")
	private List<BankDetail> listBanks;

	public Collection<BankDetail> getListBanks() {
		return listBanks;
	}

	public void setListBanks(List<BankDetail> listBanks) {
		this.listBanks = (List<BankDetail>) listBanks;
	}

	public Account() {
		// TODO Auto-Generated constructor stub
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
