package com.rioc.ws.models.dao.dto;

import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@NoArgsConstructor @AllArgsConstructor @Builder

public class AccountDto {
    @NotNull @NotBlank @NotEmpty
    private String firstName;

    @NotNull @NotBlank @NotEmpty
    private String lastName;
    @Valid
    private AdresseDto adresse;

    @Valid
    private List<BankDetailDto> listBanks;

    public List<BankDetailDto> getListBanks() {
        return listBanks;
    }

    public void setListBanks(List<BankDetailDto> listBanks) {
        this.listBanks = listBanks;
    }

    public String getLastName() {
        return lastName;
    }
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public AdresseDto getAdresse() {
        return adresse;
    }

    public void setAdresse(AdresseDto adresse) {
        this.adresse = adresse;
    }
}
