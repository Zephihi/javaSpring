package com.rioc.ws.models.dao.dto;

import com.sun.istack.NotNull;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

public class BankDetailDto {
    @NotNull @NotBlank
    @NotEmpty
    private String IBAN;

    public BankDetailDto() {
    }

    public String getIBAN() {
        return IBAN;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }
}
