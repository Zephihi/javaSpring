package com.rioc.ws.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rioc.ws.models.dao.Adresse;
import com.rioc.ws.models.dao.dto.AdresseDto;
import com.rioc.ws.services.hello.adresse.IAdresseService;
import io.netty.handler.codec.json.JsonObjectDecoder;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import springfox.documentation.spring.web.json.Json;

import javax.validation.Valid;
import java.util.List;


@RestController
public class AdresseController {
    private IAdresseService service;

    public AdresseController(IAdresseService service) {
        super();
        this.service = service;
    }
    @GetMapping("/adresse")
    public AdresseDto getAdresse(@RequestParam int id) {
        return service.getAdresseById(id);
    }
}
