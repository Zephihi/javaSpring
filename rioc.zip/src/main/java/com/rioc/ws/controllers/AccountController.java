package com.rioc.ws.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rioc.ws.exceptions.ApiException;
import com.rioc.ws.models.dao.dto.AccountDto;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.rioc.ws.models.dao.Account;
import com.rioc.ws.services.hello.account.IAccountService;

import javax.validation.Valid;
import java.util.List;

@RestController

public class AccountController {
	private IAccountService service;
	public AccountController(IAccountService service) {
		super();
		this.service = service;
	}
	@PostMapping("/accounts")
	public Account postAccount (@RequestBody @Valid AccountDto account, BindingResult result) throws JsonProcessingException {
		if(result.hasErrors()){
			throw new ApiException("Bad Entry", HttpStatus.BAD_REQUEST);
		}
		return service.postAccount(account);
	}

	@GetMapping("/accounts")
	public AccountDto getAccount(@RequestParam int id) {
		return service.getAccountById(id);
	}
	@GetMapping("/accounts/all")
	public List<AccountDto> getAllAccounts(){
		return service.getAllAccounts();
	}
	@DeleteMapping("/accounts")
	public String account(@RequestParam int id) {
		service.deleteAccount(id);
		return "Le compte a été supprimé";
	}
}