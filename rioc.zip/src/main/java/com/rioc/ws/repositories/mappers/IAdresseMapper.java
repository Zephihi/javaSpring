package com.rioc.ws.repositories.mappers;


import com.rioc.ws.models.dao.Adresse;
import com.rioc.ws.models.dao.dto.AdresseDto;
import org.mapstruct.Mapper;

@Mapper
public interface IAdresseMapper {
    AdresseDto AdresseToAdressDto(Adresse adresse);
    Adresse AdresseDtoToAdresse(AdresseDto adresseDto);
}
