package com.rioc.ws.repositories.mappers;

import com.rioc.ws.models.dao.Adresse;
import com.rioc.ws.models.dao.BankDetail;
import com.rioc.ws.models.dao.dto.AdresseDto;
import com.rioc.ws.models.dao.dto.BankDetailDto;

public interface IBankDetailMapper {
    BankDetailDto BankDetailToBankDetailDto(BankDetail bank);
    BankDetail BankDetailDtoToBankDetail(BankDetailDto BankDetailDto);
}
