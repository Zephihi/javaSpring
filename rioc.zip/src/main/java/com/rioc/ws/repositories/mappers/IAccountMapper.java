package com.rioc.ws.repositories.mappers;

import com.rioc.ws.models.dao.Account;
import com.rioc.ws.models.dao.dto.AccountDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface IAccountMapper {
    AccountDto AccountToAccountDto(Account account);
    Account AccountDtoToAccount(AccountDto account);
}
