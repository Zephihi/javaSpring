package com.rioc.ws.repositories;

import com.rioc.ws.models.dao.Adresse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IAdresseRepository extends JpaRepository<Adresse, Integer> {

}
